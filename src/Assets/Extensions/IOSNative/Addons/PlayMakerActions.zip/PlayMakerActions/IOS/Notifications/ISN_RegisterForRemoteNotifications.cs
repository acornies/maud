﻿using UnityEngine;
using UnionAssets.FLE;
using System.Collections;
using HutongGames.PlayMaker;

namespace HutongGames.PlayMaker.Actions {
		
	[ActionCategory("IOS Native - Notifications")]
	public class ISN_RegisterForRemoteNotifications : FsmStateAction {

		public FsmString deviceToken;

		#if UNITY_IPHONE
		public RemoteNotificationType type;
		#endif
	
		public override void OnEnter() {
			#if UNITY_IPHONE
			IOSNotificationController.instance.addEventListener (IOSNotificationController.DEVICE_TOKEN_RECEIVED, OnTokenReived);
			IOSNotificationController.instance.RegisterForRemoteNotifications (type);
			#endif
		}

		private void OnTokenReived(CEvent e) {
			#if UNITY_IPHONE
			IOSNotificationDeviceToken token = e.data as IOSNotificationDeviceToken;
			IOSNotificationController.instance.removeEventListener (IOSNotificationController.DEVICE_TOKEN_RECEIVED, OnTokenReived);
		
			deviceToken = token.tokenString;
			Finish ();
			#endif
		}
	}
}





