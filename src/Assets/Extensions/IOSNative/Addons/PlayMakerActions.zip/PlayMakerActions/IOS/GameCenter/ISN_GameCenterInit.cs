﻿using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Game Cneter")]
	[Tooltip("Init Game Cneter. Best practice to do this on appplicaton start")]
	public class ISN_GameCenterInit : FsmStateAction {

		public FsmEvent successEvent;
		public FsmEvent failEvent;
		
		public override void Reset() {
			
		}

		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}
			
			
			GameCenterManager.OnAuthFinished += OnAuthFinished;
			GameCenterManager.init();
			
		}

		private void OnAuthFinished (ISN_Result res) {
			GameCenterManager.OnAuthFinished -= OnAuthFinished;
			if(res.IsSucceeded) {
				Fsm.Event(successEvent);
			} else {
				Fsm.Event(failEvent);
			}

			Finish();
		}




	}
}

